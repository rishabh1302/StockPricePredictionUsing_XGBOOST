import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pickle

ax = pickle.load(open('myplot.pickle','rb'))
plt.show()