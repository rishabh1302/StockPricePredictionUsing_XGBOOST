def myQuit():
    #TODO: Add saving logic here
    exit(0)