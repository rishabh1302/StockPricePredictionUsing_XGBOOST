



def ANNRegressor():
    pass

def ANNTrain(clf,X_train,y_train):
    pass

def ANNPredict(clf,X_test):
    pass